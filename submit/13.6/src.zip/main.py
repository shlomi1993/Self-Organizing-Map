# Shlomi Ben-Shushan 311408264


# File: main.py
# Content: The entry-point of the program.


from src.app import App


if __name__ == '__main__':
    app = App()
    app.mainloop()


# Todo: Write report -- 13/6
